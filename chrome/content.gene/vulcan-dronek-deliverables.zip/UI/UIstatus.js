/*
 *  UI status.js - functions supporting the UI status line
 */

function setONOFFbutton(state)
{
	byId("onoffButton").setAttribute( "src", imgsPath + "brain." + state + ".png");
}

//  add statusbarpanel node to sb
//  
function addSBP(opts,sb) 
{
	sb = sb || statusBar;
	var ele = document.createElement("statusbarpanel");
	setAttributes( ele, opts);
	sb.appendChild( ele );
}

//  function to add an image node to statusBar
function addSBI(opts,sb)
{
	sb = sb || statusBar;
	var ele = createElement("image", opts);
	sb.appendChild( ele );
}


//  handle clicks to onoff button
function onoffClickHandler(ele)  
{
	var isOn = ele.src.match(/\.on\./);
	if ( isOn ) 
		ele.src = ele.src.replace(/\.on\./,".off.");
	else
	 	ele.src = ele.src.replace(/\.off\./,".on.");
		
	//  notify sample of change
	if ( window.userControl )
		window.userControl( !isON );
}



function statusInit() {

	if ( statusBar )
		return;						//  only initialize once
	statusBar = document.getElementById("status-bar");		//  convenience handle
	
	addSBP( { label: "done", onclick: "doneHandler(this)" });
	addSBI( arrowLeft );
	for (var n = 6; n > 0; n--) {
		addSBP( {	
					id:			"s" + n,
					label:		"s" + ("9").rep(random(6)),
					style:		sbpStyle,
			      	onclick:		"genericClickHandler(this,event)",  
			      	onmouseover:	"genericOverHandler(this,event)", 
			      	onmousemove:	null
			     } );
	}
	addSBI( arrowRight );
	addSBI( popupButton );
	addSBI( onoffButton );
}

function statusClose()
{
	//  clear out status line
}